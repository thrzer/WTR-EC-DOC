/**
 * @file HWT101CT_sdk.h
 * @author Lyn Liam (Quan.2003@outlook.com)
 * @brief  WitHWT101CT陀螺仪
 * @version 0.1
 * @date 2024-01-13
 *
 * 使用说明：
 * 要求：0
 *  波特率：115200
 *  实现函数：Delayms()
 *  更改串口宏定义： HUART_CURRENT   (第37行)
 *
 * 使用：
 *  初始化函数：      HW101_Init();
 *  循环调用：       ProcessData();
 *  数据将会出现在 本文件的 gyrodata[3] 变量，
 *      gyrodata[0]、gyrodata[1]为角加速度 y,z 轴
 *      gyrodata[1]            为角度     z 轴
 *  特性:
 *  上电零点
 *  陀螺仪数据输出角度制
 *  逆时针旋转 0->180->-180->0
 * @copyright Copyright (c) 2024
 *
 */

#ifndef HWT101CT_SDK_H
#define HWT101CT_SDK_H

#ifdef __cplusplus
extern "C" {
#endif
/**--------------------------C-----------------------------**/
#include "main.h"
#include "usart.h"
#include "wit_c_sdk.h"
#include<stdio.h>

#define  HUART_CURRENT  huart2

#define ACC_UPDATE		0x01
#define GYRO_UPDATE		0x02
#define ANGLE_UPDATE	0x04
#define MAG_UPDATE		0x08
#define READ_UPDATE		0x80


extern float fAcc[3], fGyro[3], fAngle[3];
extern const uint32_t c_uiBaud[10];

extern float gyrodata[3];
typedef union
{
    float data;
    uint8_t byte[4];
}float_to_byte;

extern float_to_byte data_imu[13];

void ProcessData(void);
void WIT_UART_RxCpltCallback(UART_HandleTypeDef *huart);
void UsartInit(UART_HandleTypeDef huart, USART_TypeDef* USART,unsigned int uiBaud);
uint8_t HW101_Init(void);


#ifdef __cplusplus
};
/**-----------------------------C++---------------------------**/
#endif

#endif // !HWT101CT_SDK_H
