import pyrealsense2 as rs
import numpy as np
import cv2
import time

# 设置RealSense D435i的配置
pipeline = rs.pipeline()
config = rs.config()

# 配置分辨率为1280x720，并启用彩色图像流
config.enable_stream(rs.stream.color, 1280, 720, rs.format.bgr8, 30)

# 启动流
pipeline.start(config)

# 保存图片的文件夹路径
save_path = "D:\Project\python\wtr\database\\basketballhoops\images\\1280_720"  # 确保你已经创建了这个文件夹

# 用于记录时间的变量
frame_interval = 0.5  # 每隔0.5秒保存一帧
capturing = False  # 控制是否开始拍摄

# 用于记录时间戳
last_saved_time = time.time()

# 循环读取帧并保存图片
try:
    while True:
        # 等待下一帧
        frames = pipeline.wait_for_frames()
        color_frame = frames.get_color_frame()
        
        if not color_frame:
            continue
        
        # 获取图像数据
        color_image = np.asanyarray(color_frame.get_data())

        # 获取当前时间戳
        timestamp = time.time()

        # 按"a"开始拍摄
        key = cv2.waitKey(1) & 0xFF
        if key == ord('a'):  # 按下'a'开始拍摄
            capturing = True
            print("Started capturing frames...")

        # 按"b"结束拍摄
        if key == ord('b'):  # 按下'b'结束拍摄
            capturing = False
            print("Stopped capturing frames.")

        # 如果正在拍摄，并且达到保存间隔
        if capturing and timestamp - last_saved_time >= frame_interval:
            filename = f"{save_path}frame_{int(timestamp)}.png"
            cv2.imwrite(filename, color_image)
            print(f"Saved: {filename}")
            last_saved_time = timestamp

        # 显示实时图像（可选）
        cv2.imshow("RealSense", color_image)

       
        # 按'Esc'退出
        if cv2.waitKey(1) & 0xFF == 27:
            break


except KeyboardInterrupt:
    print("Interrupted by user")

finally:
    # 停止流
    pipeline.stop()
    cv2.destroyAllWindows()
