'''
by z 2025.7.18
'''
#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32MultiArray

class VisionRecognitionNode(Node):
    def __init__(self):
        super().__init__('vision_recognition_node')

        self.xyz_publisher = self.create_publisher(
            Float32MultiArray,
            '/camera_xyz',
            10
        )

        self.get_logger().info('Vision Recognition Node has been started.')

    def pub_xyz(self, xyz):
        msg = Float32MultiArray()
        msg.data.append(xyz[0])
        msg.data.append(xyz[1])
        msg.data.append(xyz[2])
        self.xyz_publisher.publish(msg)


import platform
import pathlib
plt = platform.system()
if plt != 'Windows':
    pathlib.WindowsPath = pathlib.PosixPath

# 导入依赖
import random
from utils.torch_utils import select_device, load_classifier, time_sync
from utils.general import (
    check_img_size, non_max_suppression, apply_classifier, scale_coords,
    xyxy2xywh, strip_optimizer, set_logging)
from utils.datasets import LoadStreams, LoadImages, letterbox
from models.experimental import attempt_load
import torch.backends.cudnn as cudnn
import torch
import pyrealsense2 as rs
import yaml
import time
import numpy as np
import cv2
# PyTorch
# YoloV5-PyTorch

pipeline = rs.pipeline()  # 定义流程pipeline
config = rs.config()  # 定义配置config
config.enable_stream(rs.stream.depth, 1280,720, rs.format.z16, 30)
config.enable_stream(rs.stream.color, 1280,720, rs.format.bgr8, 30)
profile = pipeline.start(config)  # 流程开始
align_to = rs.stream.color  # 与color流对齐
align = rs.align(align_to)


def get_aligned_images():
    frames = pipeline.wait_for_frames()  # 等待获取图像帧
    aligned_frames = align.process(frames)  # 获取对齐帧
    aligned_depth_frame = aligned_frames.get_depth_frame()  # 获取对齐帧中的depth帧
    color_frame = aligned_frames.get_color_frame()  # 获取对齐帧中的color帧

    ############### 相机参数的获取 #######################
    intr = color_frame.profile.as_video_stream_profile().intrinsics  # 获取相机内参
    depth_intrin = aligned_depth_frame.profile.as_video_stream_profile(
    ).intrinsics  # 获取深度参数（像素坐标系转相机坐标系会用到）
    '''camera_parameters = {'fx': intr.fx, 'fy': intr.fy,
                         'ppx': intr.ppx, 'ppy': intr.ppy,
                         'height': intr.height, 'width': intr.width,
                         'depth_scale': profile.get_device().first_depth_sensor().get_depth_scale()
                         }'''

    # 保存内参到本地
    # with open('./intrinsics.json', 'w') as fp:
    #json.dump(camera_parameters, fp)
    #######################################################

    depth_image = np.asanyarray(aligned_depth_frame.get_data())  # 深度图（默认16位）
    depth_image_8bit = cv2.convertScaleAbs(depth_image, alpha=0.03)  # 深度图（8位）
    depth_image_3d = np.dstack(
        (depth_image_8bit, depth_image_8bit, depth_image_8bit))  # 3通道深度图
    color_image = np.asanyarray(color_frame.get_data())  # RGB图

    # 返回相机内参、深度参数、彩色图、深度图、齐帧中的depth帧
    return intr, depth_intrin, color_image, depth_image, aligned_depth_frame


class YoloV5:
    def __init__(self, yolov5_yaml_path='wtr\yolov5_d435i_detection-main\config\yolov5s.yaml'):
        '''初始化'''
        # 载入配置文件
        with open(yolov5_yaml_path, 'r', encoding='utf-8') as f:
            self.yolov5 = yaml.load(f.read(), Loader=yaml.SafeLoader)
        # 随机生成每个类别的颜色
        self.colors = [[np.random.randint(0, 255) for _ in range(
            3)] for class_id in range(self.yolov5['class_num'])]
        # 模型初始化
        self.init_model()

    @torch.no_grad()
    def init_model(self):
        '''模型初始化'''
        # 设置日志输出
        set_logging()
        # 选择计算设备
        device = select_device(self.yolov5['device'])
        # 如果是GPU则使用半精度浮点数 F16
        is_half = device.type != 'cpu'
        # 载入模型
        model = attempt_load(
            self.yolov5['weight'], map_location=device)  # 载入全精度浮点数的模型
        # from ultralytics import YOLOv5

        input_size = check_img_size(
            self.yolov5['input_size'], s=model.stride.max())  # 检查模型的尺寸
        if is_half:
            model.half()  # 将模型转换为半精度
        # 设置BenchMark，加速固定图像的尺寸的推理
        cudnn.benchmark = True  # set True to speed up constant image size inference
        # 图像缓冲区初始化
        img_torch = torch.zeros(
            (1, 3, self.yolov5['input_size'], self.yolov5['input_size']), device=device)  # init img
        # 创建模型
        # run once
        #_ = model(img_torch.half()
         #         if is_half else img) if device.type != 'cpu' else None
        self.is_half = is_half  # 是否开启半精度
        self.device = device  # 计算设备
        self.model = model  # Yolov5模型
        self.img_torch = img_torch  # 图像缓冲区

    def preprocessing(self, img):
        '''图像预处理'''
        # 图像缩放
        # 注: auto一定要设置为False -> 图像的宽高不同
        img_resize = letterbox(img, new_shape=(
            self.yolov5['input_size'], self.yolov5['input_size']), auto=False)[0]
        # print("img resize shape: {}".format(img_resize.shape))
        # 增加一个维度
        img_arr = np.stack([img_resize], 0)
        # 图像转换 (Convert) BGR格式转换为RGB
        # 转换为 bs x 3 x 416 x
        # 0(图像i), 1(row行), 2(列), 3(RGB三通道)
        # ---> 0, 3, 1, 2
        # BGR to RGB, to bsx3x416x416
        img_arr = img_arr[:, :, :, ::-1].transpose(0, 3, 1, 2)
        # 数值归一化
        # img_arr =  img_arr.astype(np.float32) / 255.0
        # 将数组在内存的存放地址变成连续的(一维)， 行优先
        # 将一个内存不连续存储的数组转换为内存连续存储的数组，使得运行速度更快
        # https://zhuanlan.zhihu.com/p/59767914
        img_arr = np.ascontiguousarray(img_arr)
        return img_arr

    @torch.no_grad()
    def detect(self, img, canvas=None, view_img=True):
        '''模型预测'''
        # 图像预处理
        img_resize = self.preprocessing(img)  # 图像缩放
        self.img_torch = torch.from_numpy(img_resize).to(self.device)  # 图像格式转换
        self.img_torch = self.img_torch.half(
        ) if self.is_half else self.img_torch.float()  # 格式转换 uint8-> 浮点数
        self.img_torch /= 255.0  # 图像归一化
        if self.img_torch.ndimension() == 3:
            self.img_torch = self.img_torch.unsqueeze(0)
        # 模型推理
        t1 = time_sync()
        pred = self.model(self.img_torch, augment=False)[0]
        # pred = self.model_trt(self.img_torch, augment=False)[0]
        # NMS 非极大值抑制
        pred = non_max_suppression(pred, self.yolov5['threshold']['confidence'],
                                   self.yolov5['threshold']['iou'], classes=None, agnostic=False)
        t2 = time_sync()
        # print("推理时间: inference period = {}".format(t2 - t1))
        # 获取检测结果
        det = pred[0]
        gain_whwh = torch.tensor(img.shape)[[1, 0, 1, 0]]  # [w, h, w, h]

        if view_img and canvas is None:
            canvas = np.copy(img)
        xyxy_list = []
        conf_list = []
        class_id_list = []
        if det is not None and len(det):
            # 画面中存在目标对象
            # 将坐标信息恢复到原始图像的尺寸
            det[:, :4] = scale_coords(
                img_resize.shape[2:], det[:, :4], img.shape).round()
            for *xyxy, conf, class_id in reversed(det):
                class_id = int(class_id)
                xyxy_list.append(xyxy)
                conf_list.append(conf)
                class_id_list.append(class_id)
                if view_img:
                    # 绘制矩形框与标签
                    label = '%s %.2f' % (
                        self.yolov5['class_name'][class_id], conf)
                    self.plot_one_box(
                        xyxy, canvas, label=label, color=self.colors[class_id], line_thickness=3)
        return canvas, class_id_list, xyxy_list, conf_list

    def plot_one_box(self, x, img, color=None, label=None, line_thickness=None):
        ''''绘制矩形框+标签'''
        tl = line_thickness or round(
            0.002 * (img.shape[0] + img.shape[1]) / 2) + 1  # line/font thickness
        color = color or [random.randint(0, 255) for _ in range(3)]
        c1, c2 = (int(x[0]), int(x[1])), (int(x[2]), int(x[3]))
        cv2.rectangle(img, c1, c2, color, thickness=tl, lineType=cv2.LINE_AA)
        if label:
            tf = max(tl - 1, 1)  # font thickness
            t_size = cv2.getTextSize(
                label, 0, fontScale=tl / 3, thickness=tf)[0]
            c2 = c1[0] + t_size[0], c1[1] - t_size[1] - 3
            cv2.rectangle(img, c1, c2, color, -1, cv2.LINE_AA)  # filled
            cv2.putText(img, label, (c1[0], c1[1] - 2), 0, tl / 3,
                        [225, 255, 255], thickness=tf, lineType=cv2.LINE_AA)


if __name__ == '__main__':
    rclpy.init()
    print("[INFO] YoloV5目标检测-程序启动")
    print("[INFO] 开始YoloV5模型加载")
    # YOLOV5模型配置文件(YAML格式)的路径 yolov5_yaml_path
    model = YoloV5(yolov5_yaml_path='wtr\yolov5_d435i_detection-main\config\yolov5s.yaml')
    print("[INFO] 完成YoloV5模型加载")

    try:
        while True:
            # Wait for a coherent pair of frames: depth and color
            intr, depth_intrin, color_image, depth_image, aligned_depth_frame = get_aligned_images()  # 获取对齐的图像与相机内参
            if not depth_image.any() or not color_image.any():
                continue
            # Convert images to numpy arrays
            # Apply colormap on depth image (image must be converted to 8-bit per pixel first)
            depth_colormap = cv2.applyColorMap(cv2.convertScaleAbs(
                depth_image, alpha=0.03), cv2.COLORMAP_JET)
            # Stack both images horizontally
            images = np.hstack((color_image, depth_colormap))
            
            # Show images

            t_start = time.time()  # 开始计时
            # YoloV5 目标检测
            canvas, class_id_list, xyxy_list, conf_list = model.detect(
                color_image)

            t_end = time.time()  # 结束计时\
            #canvas = np.hstack((canvas, depth_colormap))
            #print(class_id_list)
            # ---------- 终极暗光增强 + 篮筐红橙像素 ----------
            # 0. 双重 Gamma：提亮暗部 + 抑制过曝
            def dual_gamma(img, g1=1.8, g2=0.8):
                table1 = np.array([((i / 255.0) ** (1.0 / g1)) * 255
                                   for i in np.arange(256)]).astype(np.uint8)
                table2 = np.array([((i / 255.0) ** (1.0 / g2)) * 255
                                   for i in np.arange(256)]).astype(np.uint8)
                bright = cv2.LUT(img, table1)
                comp = cv2.LUT(bright, table2)
                return comp

            # 1. 灰度世界白平衡
            def white_balance(img):
                b, g, r = cv2.split(img)
                b_avg, g_avg, r_avg = np.mean(b), np.mean(g), np.mean(r)
                k = (b_avg + g_avg + r_avg) / 3
                b = np.clip(b * k / b_avg, 0, 255).astype(np.uint8)
                g = np.clip(g * k / g_avg, 0, 255).astype(np.uint8)
                r = np.clip(r * k / r_avg, 0, 255).astype(np.uint8)
                return cv2.merge([b, g, r])

            # 2. CLAHE + 饱和度拉伸
            def enhance_color(img, clip=2.5, grid=(8, 8)):
                hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
                h, s, v = cv2.split(hsv)
                # CLAHE on V
                clahe = cv2.createCLAHE(clipLimit=clip, tileGridSize=grid)
                v = clahe.apply(v)
                # 饱和度拉伸
                s = cv2.normalize(s, None, 50, 255, cv2.NORM_MINMAX)
                enhanced = cv2.merge([h, s, v])
                return cv2.cvtColor(enhanced, cv2.COLOR_HSV2BGR)

            # 3. HSV 阈值（再次扩大）
            lower = np.array([0,   35,  35])
            upper = np.array([30, 255, 255])

            camera_xyz_list = []

            if xyxy_list:
                for box in xyxy_list:
                    x1, y1, x2, y2 = map(int, box)
                    w, h = x2 - x1, y2 - y1
                    if w <= 1 or h <= 1:
                        continue

                    roi = color_image[y1:y2, x1:x2]

                    # ---------- 增强链路 ----------
                    roi = dual_gamma(roi)
                    roi = white_balance(roi)
                    roi = enhance_color(roi)
                    roi = cv2.medianBlur(roi, 5)

                    roi_hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
                    mask = cv2.inRange(roi_hsv, lower, upper)

                    # 形态学：先膨胀再腐蚀（闭运算）
                    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
                    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, 2)

                    # ---------- 强制均匀 10 点 ----------
                    ys_all, xs_all = np.where(mask > 0)
                    total_pixels = len(xs_all)
                    if total_pixels >= 10:
                        idx = np.linspace(0, total_pixels - 1, 10, dtype=int)
                        valid = [(int(x1 + xs_all[i]), int(y1 + ys_all[i])) for i in idx]
                    elif total_pixels > 0:
                        # 不足 10 个就全部要，再线性插值补到 10 个
                        valid = [(int(x1 + xs_all[i]), int(y1 + ys_all[i]))
                                 for i in range(total_pixels)]
                        # 线性插值补点
                        if len(valid) >= 2:
                            for i in range(10 - total_pixels):
                                t = (i + 1) / (10 - total_pixels + 1)
                                px = int(valid[0][0] * (1 - t) + valid[-1][0] * t)
                                py = int(valid[0][1] * (1 - t) + valid[-1][1] * t)
                                valid.append((px, py))
                        else:
                            # 只剩 1 个像素，直接复制 9 次
                            valid.extend([valid[0]] * (10 - total_pixels))
                    else:
                        # 一个都没有就回退到中心
                        cx, cy = (x1 + x2) // 2, (y1 + y2) // 2
                        valid = [(cx, cy)] * 10

                    # ---------- 深度 ----------
                    depths = [aligned_depth_frame.get_distance(ux, uy)
                              for ux, uy in valid if 0.1 < aligned_depth_frame.get_distance(ux, uy) < 10.0]
                    avg_depth = np.mean(depths) if depths else aligned_depth_frame.get_distance(
                        (x1 + x2) // 2, (y1 + y2) // 2)

                    # ---------- 反投影（中心固定） ----------
                    cx, cy = (x1 + x2) // 2, (y1 + y2) // 2
                    camera_xyz = rs.rs2_deproject_pixel_to_point(depth_intrin, (cx, cy), avg_depth)
                    camera_xyz = np.round(np.array(camera_xyz), 3).tolist()
                    camera_xyz_list.append(camera_xyz)
                    camera_node.pub_xyz(camera_xyz)
                    # ---------- 画图 ----------
                    for px, py in valid:
                        cv2.circle(canvas, (px, py), 3, (0, 255, 0), -1)   # 绿点
                    cv2.circle(canvas, (cx, cy), 5, (0, 255, 255), -1)     # 黄中心
                    cv2.putText(canvas, str(camera_xyz), (cx + 10, cy - 10),
                                0, 1, [0, 255, 255], 2, cv2.LINE_AA)
                                
                    
            #print(camera_xyz_list)

            # 添加fps显示
            fps = int(1.0 / (t_end - t_start))
            cv2.putText(canvas, text="FPS: {}".format(fps), org=(50, 50),
                        fontFace=cv2.FONT_HERSHEY_SIMPLEX, fontScale=1, thickness=2,
                        lineType=cv2.LINE_AA, color=(0, 0, 0))
            cv2.namedWindow('detection', flags=cv2.WINDOW_NORMAL |
                            cv2.WINDOW_KEEPRATIO | cv2.WINDOW_GUI_EXPANDED)
            # cv2.imshow('detection', canvas)
            # 将深度图转为伪彩色（8位）
            depth_colormap = cv2.applyColorMap(
                cv2.convertScaleAbs(depth_image, alpha=0.03), cv2.COLORMAP_JET
            )

            # 左右拼接彩色图与深度图
            combined = np.hstack((canvas, depth_colormap))

            # 显示拼接后的图像
            cv2.imshow('detection', combined)
            key = cv2.waitKey(1)
            # Press esc or 'q' to close the image window
            if key & 0xFF == ord('q') or key == 27:
                cv2.destroyAllWindows()
                break
    finally:
        # Stop streaming
        pipeline.stop()
 
