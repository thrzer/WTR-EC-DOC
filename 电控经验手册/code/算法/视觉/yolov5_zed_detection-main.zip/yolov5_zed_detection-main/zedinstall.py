import sys
import pyzed.sl as sl
import numpy as np
import cv2
import argparse

def parse_args(init, opt):
    if len(opt.input_svo_file)>0 and opt.input_svo_file.endswith(".svo"):
        init.set_from_svo_file(opt.input_svo_file)
        print("[示例] 使用 SVO 文件输入: {0}".format(opt.input_svo_file))
    elif len(opt.ip_address)>0 :
        ip_str = opt.ip_address
        if ip_str.replace(':','').replace('.','').isdigit() and len(ip_str.split('.'))==4 and len(ip_str.split(':'))==2:
            init.set_from_stream(ip_str.split(':')[0],int(ip_str.split(':')[1]))
            print("[示例] 使用流输入，IP : ",ip_str)
        elif ip_str.replace(':','').replace('.','').isdigit() and len(ip_str.split('.'))==4:
            init.set_from_stream(ip_str)
            print("[示例] 使用流输入，IP : ",ip_str)
        else :
            print("无效的IP格式。使用实时流")

    # 设置摄像头分辨率为 1280x720 (HD720)
    init.camera_resolution = sl.RESOLUTION.HD720
    print("[示例] 使用 1280x720 分辨率的摄像头")

def get_distance_from_object(opt):
    print("运行深度感知示例 ... 按 'Esc' 退出\n按 's' 保存点云数据")

    init = sl.InitParameters(depth_mode=sl.DEPTH_MODE.QUALITY,
                              coordinate_units=sl.UNIT.METER,
                              coordinate_system=sl.COORDINATE_SYSTEM.RIGHT_HANDED_Y_UP)
    parse_args(init, opt)
    zed = sl.Camera()
    status = zed.open(init)
    if status != sl.ERROR_CODE.SUCCESS:
        print(repr(status))
        exit()

    # 获取相机信息
    camera_info = zed.get_camera_information()
    calibration_params = camera_info.camera_configuration.calibration_parameters

    # 获取左相机的内参
    fx = calibration_params.left_cam.fx
    fy = calibration_params.left_cam.fy
    cx = calibration_params.left_cam.cx
    cy = calibration_params.left_cam.cy

    # 创建一个Mat对象，用于存储深度图像
    depth_image = sl.Mat()

    # 创建一个OpenCV窗口来显示深度图像
    cv2.namedWindow("Depth Map", cv2.WINDOW_NORMAL)

    while True:
        # 获取当前的深度图像
        if zed.grab() == sl.ERROR_CODE.SUCCESS:
            # 获取深度图像
            zed.retrieve_measure(depth_image, sl.MEASURE.DEPTH)

            # 转换深度图像为OpenCV格式
            depth_array = depth_image.get_data()
            depth_array = np.array(depth_array, dtype=np.float32)

            # 选择一个像素位置 
            width = depth_image.get_width()
            height = depth_image.get_height()
            top_left_x = 500  # 矩形框的中心点相对于画面中心点的x坐标
            top_left_y = 500 # 矩形框的中心点相对于画面中心点的y坐标
            # 计算中心点坐标
            center_x = width // 2
            center_y = height // 2
            # 获取该像素的深度值（单位为米）
            depth_value = depth_array[top_left_y, top_left_x]

            # 通过相机内参和深度值计算物理距离
            if depth_value > 0:
                # 从相机中心投影出来的深度值（根据相机内参计算）
                x = (top_left_x - center_x) * depth_value / fx
                y = (top_left_y - center_y) * depth_value / fy
                z = depth_value  # Z轴为深度值

                # 输出物理坐标
                print(f"矩形框的中心点的物理坐标: x={x:.2f} 米, y={y:.2f} 米, z={z:.2f} 米")
                
            else:
                print("该位置的深度值无效，可能是背景或空白区域")

            # 在图像中标出该点
            image = cv2.cvtColor(depth_array.astype(np.uint8), cv2.COLOR_GRAY2BGR)
            cv2.circle(image, (top_left_x, top_left_y), 10, (0, 0, 255), -1)  # 在左上角画一个红圈

            # 计算中心点坐标
            center_x = width // 2
            center_y = height // 2
            cv2.circle(image, (center_x, center_y), 10, (0, 255, 0), -1)  # 在中心点画一个绿色圆圈

            # 显示深度图像（根据需要，可以通过归一化来显示更清晰的图像）
            depth_display = cv2.normalize(depth_array, None, 0, 255, cv2.NORM_MINMAX)
            depth_display = np.uint8(depth_display)  # 转换为8位图像

            # 显示带标记的图像
            cv2.imshow("Depth Map", image)

        # 等待键盘输入，不按'q'时继续
        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):  # 按下 'q' 键退出
            break

    # 关闭相机
    zed.close()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--input_svo_file', type=str, help='如果您想回放，请提供 .svo 文件路径', default = '')
    parser.add_argument('--ip_address', type=str, help='IP 地址，格式为 a.b.c.d:port 或 a.b.c.d， 如果您有流媒体设置', default = '')
    parser.add_argument('--resolution', type=str, help='分辨率，目前为 HD720', default = 'HD720')
    opt = parser.parse_args()

    if len(opt.input_svo_file)>0 and len(opt.ip_address)>0:
        print("只能指定 input_svo_file 或 ip_address，或者都不指定来使用有线摄像头，不可以同时指定两者。退出程序")
        exit()

    get_distance_from_object(opt)
