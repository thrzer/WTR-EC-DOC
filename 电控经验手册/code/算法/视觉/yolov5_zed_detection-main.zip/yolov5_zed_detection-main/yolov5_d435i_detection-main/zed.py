import os
import cv2
import time
import pyzed.sl as sl

# ------------------------------------------------
# 1. 基本参数
# ------------------------------------------------
save_dir = r"D:\adddatabase\zed\images"  # 改为你自己的路径
os.makedirs(save_dir, exist_ok=True)

frame_interval = 0.2        # 每隔多少秒保存一帧；设为 0 则每帧都存
capture_flag   = False      # 是否开始保存（可运行时按 'a'/'b' 控制）

# ------------------------------------------------
# 2. 初始化 ZED
# ------------------------------------------------
zed = sl.Camera()

init_params = sl.InitParameters()
init_params.camera_resolution = sl.RESOLUTION.HD720      # 2208×1242
init_params.camera_fps        = 15                      # HD2K 下最高 15 fps
init_params.coordinate_units  = sl.UNIT.METER
init_params.depth_mode        = sl.DEPTH_MODE.NONE      # 只采图，不开深度

err = zed.open(init_params)
if err != sl.ERROR_CODE.SUCCESS:
    print("ZED 打开失败:", err)
    exit(1)

# ------------------------------------------------
# 3. 主循环
# ------------------------------------------------
runtime = sl.RuntimeParameters()
mat     = sl.Mat()              # 用于接收图像

last_save_t = time.time()

print("按下 'a' 开始保存，'b' 停止保存，ESC 退出...")

while True:
    if zed.grab(runtime) != sl.ERROR_CODE.SUCCESS:
        continue

    # 1. 取左目彩色图
    zed.retrieve_image(mat, sl.VIEW.LEFT, sl.MEM.CPU)
    img = mat.get_data()                # 返回 numpy.ndarray (1242, 2208, 4) BGRA
    img_bgr = cv2.cvtColor(img, cv2.COLOR_BGRA2BGR)

    # 2. 实时预览
    cv2.imshow("ZED HD2K", img_bgr)

    # 3. 按帧/按间隔保存
    t = time.time()
    if capture_flag and (t - last_save_t >= frame_interval):
        fname = f"frame_{int(t*1000)}.png"
        cv2.imwrite(os.path.join(save_dir, fname), img_bgr)
        print("Saved", fname)
        last_save_t = t

    # 4. 键盘控制
    key = cv2.waitKey(1) & 0xFF
    if key == ord('a'):
        capture_flag = True
        print("开始保存...")
    elif key == ord('b'):
        capture_flag = False
        print("停止保存...")
    elif key == 27:     # ESC
        break

# ------------------------------------------------
# 4. 清理
# ------------------------------------------------
zed.close()
cv2.destroyAllWindows()