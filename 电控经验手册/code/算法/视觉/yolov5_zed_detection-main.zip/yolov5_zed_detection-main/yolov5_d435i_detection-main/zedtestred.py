import random
import yaml
import time
import numpy as np
import cv2
import torch
import pyzed.sl as sl
import torch.backends.cudnn as cudnn
from utils.torch_utils import select_device, load_classifier, time_sync
from utils.general import (
    check_img_size, non_max_suppression, apply_classifier, scale_coords,
    xyxy2xywh, strip_optimizer, set_logging)
from utils.datasets import LoadStreams, LoadImages, letterbox
from models.experimental import attempt_load

# Initialize ZED Camera
def init_zed_camera():
    camera = sl.Camera()
    init_params = sl.InitParameters()
    init_params.camera_resolution = sl.RESOLUTION.HD720
    init_params.coordinate_system = sl.COORDINATE_SYSTEM.RIGHT_HANDED_Y_UP
    init_params.coordinate_units = sl.UNIT.METER
    err = camera.open(init_params)
    if err != sl.ERROR_CODE.SUCCESS:
        print(f"无法初始化相机: {err}")
        exit(1)
    return camera


def get_zed_images(camera):
    image = sl.Mat()
    if camera.grab() == sl.ERROR_CODE.SUCCESS:
        camera.retrieve_image(image, sl.VIEW.LEFT)
        color_image = np.asarray(image.get_data())
        # Convert ZED color image from BGR to RGB for OpenCV
        color_image = cv2.cvtColor(color_image, cv2.COLOR_BGR2RGB)
        return color_image
    return None

class YoloV5:
    def __init__(self, yolov5_yaml_path='D:\Project\python\wtr\yolov5_d435i_detection-main-1\yolov5_d435i_detection-main\config\yolov5s.yaml'):
        '''初始化'''
        # 载入配置文件
        with open(yolov5_yaml_path, 'r', encoding='utf-8') as f:
            self.yolov5 = yaml.load(f.read(), Loader=yaml.SafeLoader)
        # 随机生成每个类别的颜色
        self.colors = [[np.random.randint(0, 255) for _ in range(
            3)] for class_id in range(self.yolov5['class_num'])]
        # 模型初始化
        self.init_model()

    @torch.no_grad()
    def init_model(self):
        '''模型初始化'''
        # 设置日志输出
        set_logging()
        # 选择计算设备
        device = select_device(self.yolov5['device'])
        # 如果是GPU则使用半精度浮点数 F16
        is_half = device.type != 'cpu'
        # 载入模型
        model = attempt_load(
            self.yolov5['weight'], map_location=device)  # 载入全精度浮点数的模型
        input_size = check_img_size(
            self.yolov5['input_size'], s=model.stride.max())  # 检查模型的尺寸
        if is_half:
            model.half()  # 将模型转换为半精度
        # 设置BenchMark，加速固定图像的尺寸的推理
        cudnn.benchmark = True  # set True to speed up constant image size inference
        # 图像缓冲区初始化
        img_torch = torch.zeros(
            (1, 3, self.yolov5['input_size'], self.yolov5['input_size']), device=device)  # init img
        # 创建模型
        # run once
        
        self.is_half = is_half  # 是否开启半精度
        self.device = device  # 计算设备
        self.model = model  # Yolov5模型
        self.img_torch = img_torch  # 图像缓冲区

    def preprocessing(self, img):
        '''图像预处理'''
        # 图像缩放
        img_resize = letterbox(img, new_shape=(
            self.yolov5['input_size'], self.yolov5['input_size']), auto=False)[0]
        # 增加一个维度
        img_arr = np.stack([img_resize], 0)
        # 图像转换 (Convert) BGR格式转换为RGB
        img_arr = img_arr[:, :, :, ::-1].transpose(0, 3, 1, 2)
        # 数值归一化
        img_arr = np.ascontiguousarray(img_arr)
        return img_arr
    
    @torch.no_grad()
    def detect(self, img, canvas=None, view_img=True):
        '''模型预测'''
        # 图像预处理
        img_resize = self.preprocessing(img)  # 图像缩放
        self.img_torch = torch.from_numpy(img_resize).to(self.device)  # 图像格式转换
        self.img_torch = self.img_torch.half() if self.is_half else self.img_torch.float()  # 格式转换 uint8-> 浮点数
        self.img_torch /= 255.0  # 图像归一化
        if self.img_torch.ndimension() == 3:
            self.img_torch = self.img_torch.unsqueeze(0)
        
        # 模型推理
        t1 = time_sync()
        pred = self.model(self.img_torch, augment=False)[0]
        
        # NMS 非极大值抑制
        pred = non_max_suppression(pred, self.yolov5['threshold']['confidence'],
                                self.yolov5['threshold']['iou'], classes=None, agnostic=False)
        t2 = time_sync()

        # 获取检测结果
        det = pred[0]
        gain_whwh = torch.tensor(img.shape)[[1, 0, 1, 0]]  # [w, h, w, h]

        if view_img and canvas is None:
            canvas = np.copy(img)

        xyxy_list = []
        conf_list = []
        class_id_list = []
        
        if det is not None and len(det):
            # 画面中存在目标对象
            # 将坐标信息恢复到原始图像的尺寸
            det[:, :4] = scale_coords(
                img_resize.shape[2:], det[:, :4], img.shape).round()

            for *xyxy, conf, class_id in reversed(det):
                class_id = int(class_id)
                xyxy_list.append(xyxy)
                conf_list.append(conf)
                class_id_list.append(class_id)
                if view_img:
                    label = f'{self.yolov5["class_name"][class_id]} {conf:.2f}'
                    self.plot_one_box(xyxy, canvas, label=label,
                                    color=self.colors[class_id], line_thickness=3)

                    x1, y1, x2, y2 = map(int, xyxy)
                    center_x = (x1 + x2) // 2
                    center_y = (y1 + y2) // 2
                    img_center_x = img.shape[1] // 2
                    img_center_y = img.shape[0] // 2
                    offset_x = center_x - img_center_x
                    offset_y = center_y - img_center_y

                    image_depth = sl.Mat()
                    zed_camera.retrieve_measure(image_depth, sl.MEASURE.DEPTH)
                    depth_array = np.asarray(image_depth.get_data(), dtype=np.float32)

                    roi = img[y1:y2, x1:x2]
                    roi_blur = cv2.GaussianBlur(roi, (5, 5), 0)
                    hsv = cv2.cvtColor(roi_blur, cv2.COLOR_BGR2HSV)
                    h, s, v = cv2.split(hsv)
                    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
                    v_clahe = clahe.apply(v)
                    hsv_enh = cv2.merge([h, s, v_clahe])

                    mean_v = np.mean(v_clahe)
                    v_low  = max(40, int(mean_v * 0.4))
                    v_high = 255
                    s_low  = max(70, int(np.percentile(s, 30)))

                    lower_blue = np.array([100, s_low, v_low])
                    upper_blue = np.array([130, 255,  v_high])
                    mask_blue = cv2.inRange(hsv_enh, lower_blue, upper_blue)

                    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
                    mask_clean = cv2.morphologyEx(mask_blue, cv2.MORPH_OPEN, kernel, 1)
                    mask_clean = cv2.morphologyEx(mask_clean, cv2.MORPH_CLOSE, kernel, 2)

                    edge_mask = np.zeros_like(mask_clean)
                    cv2.rectangle(edge_mask, (0, 0),
                                (mask_clean.shape[1]-1, mask_clean.shape[0]-1), 255, 3)
                    mask_final = cv2.bitwise_and(mask_clean, 255 - edge_mask)

                    # 获取全部蓝色像素
                    all_blue = np.column_stack(np.where(mask_final > 0))
                    total = len(all_blue)
                    # 最多保留 10 个，且均匀分布
                    if total > 10:
                        # 按 x 坐标排序后均匀抽 10 个
                        step = max(1, total // 10)
                        idx = np.linspace(0, total - 1, 10, dtype=int)
                        blue_pixels = all_blue[idx]
                    else:
                        blue_pixels = all_blue
                    num_blue = len(blue_pixels)
                    print(f"[INFO] 篮筐 ROI 内保留 {num_blue} 个蓝色像素点")

                    # 深度均值
                    depth_points = []
                    for v_rel, u_rel in blue_pixels:
                        gx = x1 + u_rel
                        gy = y1 + v_rel
                        if 0 <= gx < img.shape[1] and 0 <= gy < img.shape[0]:
                            d = depth_array[gy, gx]
                            if np.isfinite(d) and d > 0:
                                depth_points.append(d)

                    if depth_points:
                        mean_d = np.mean(depth_points)
                        filtered = [d for d in depth_points if abs(d - mean_d) < 0.15 * mean_d]
                        blue_depth = float(np.mean(filtered)) if filtered else float(mean_d)
                    else:
                        center_depth = depth_array[center_y, center_x]
                        blue_depth = float(center_depth) if np.isfinite(center_depth) and center_depth > 0 else None

                    # 显示 XYZ
                    if blue_depth is not None:
                        fx = zed_camera.get_camera_information().camera_configuration.calibration_parameters.left_cam.fx
                        fy = zed_camera.get_camera_information().camera_configuration.calibration_parameters.left_cam.fy
                        real_x = (offset_x * blue_depth) / fx
                        real_y = (offset_y * blue_depth) / fy
                        real_z = blue_depth

                        cv2.circle(canvas, (center_x, center_y), 4, (255, 255, 255), -1)
                        coord_str = f"X:{real_x:.2f} Y:{real_y:.2f} Z:{real_z:.2f}"
                        cv2.putText(canvas, coord_str,
                                    (center_x + 10, center_y - 10),
                                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2, cv2.LINE_AA)

                        # 红色圆点标记采样点
                        for v_rel, u_rel in blue_pixels:
                            gx = x1 + u_rel
                            gy = y1 + v_rel
                            cv2.circle(canvas, (gx, gy), 2, (0, 0, 255), -1)
                              
                        print(f"real_x:{real_x:.2f},real_y:{real_y:.2f},real_z:{real_z:.2f}")


        return canvas, class_id_list, xyxy_list, conf_list
   

    def plot_one_box(self, x, img, color=None, label=None, line_thickness=None):
      '''绘制矩形框+标签+中心点'''
      tl = line_thickness or round(
        0.002 * (img.shape[0] + img.shape[1]) / 2) + 1  # line/font thickness
      color = color or [random.randint(0, 255) for _ in range(3)]
      c1, c2 = (int(x[0]), int(x[1])), (int(x[2]), int(x[3]))
      # 绘制矩形框
      cv2.rectangle(img, c1, c2, color, thickness=tl, lineType=cv2.LINE_AA)
      if label:
        tf = max(tl - 1, 1)  # font thickness
        t_size = cv2.getTextSize(
            label, 0, fontScale=tl / 3, thickness=tf)[0]
        c2 = c1[0] + t_size[0], c1[1] - t_size[1] - 3
        cv2.rectangle(img, c1, c2, color, -1, cv2.LINE_AA)  # filled
        cv2.putText(img, label, (c1[0], c1[1] - 2), 0, tl / 3,
                    [225, 255, 255], thickness=tf, lineType=cv2.LINE_AA)
    
    #   # 计算矩形框的中心点
    #   center_x = int((x[0] + x[2]) / 2)
    #   center_y = int((x[1] + x[3]) / 2)
    #   # 绘制中心点
    #   cv2.circle(img, (center_x, center_y), 5, (255, 255, 255), -1)  # 画一个白色的圆点，半径为5




if __name__ == '__main__':
    print("[INFO] YoloV5目标检测-程序启动")
    print("[INFO] 开始YoloV5模型加载")
    model = YoloV5(yolov5_yaml_path='wtr\\yolov5_d435i_detection-main-1\\yolov5_d435i_detection-main\\config\\yolov5s.yaml')
    print("[INFO] 完成YoloV5模型加载")

    # Initialize ZED Camera
    zed_camera = init_zed_camera()

    try:
        while True:
            # Get ZED color image
            color_image = get_zed_images(zed_camera)
            if color_image is None:
                continue

            # YoloV5 detection
            canvas, class_id_list, xyxy_list, conf_list = model.detect(color_image)
            canvas_bgr = cv2.cvtColor(canvas, cv2.COLOR_RGB2BGR)
            # Display the image
            cv2.imshow("YoloV5 Detection", canvas_bgr)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
    except cv2.error as e:
        print(f"OpenCV Error: {e}")
    finally:
        # Close ZED Camera
        zed_camera.close()
        cv2.destroyAllWindows()